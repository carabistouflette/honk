import json,os,sys,time
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'bench'))
from process_observer import execute
from watch_stress import terminals,canonical
out=root/'.build/ignore-real';out.mkdir();project=out/'project';(project/'src').mkdir(parents=True);(project/'tests').mkdir();(project/'src/generated').mkdir()
(project/'Honk.toml').write_text('[package]\nname="ignore_smoke"\nversion="0.1.0"\nentry="src/main.goose"\n')
entry=project/'src/main.goose';entry.write_text('fn main() {}\n');ignored=project/'src/generated/unit.goose';ignored.write_text('// generated\n')
(project/'tests/rc.goose').write_text('fn main() { print("IGNORE_REAL_OK"); }\n')
log=out/'events.log';state={}
def trigger(process,row):
 data=log.read_bytes() if log.exists() else b''
 outcomes=terminals(data)
 if not state and len(outcomes)==1:
  ignored.write_text('// ignored save\n');state['ignored_ns']=time.monotonic_ns()
 elif 'ignored_ns' in state and 'included_ns' not in state and time.monotonic_ns()-state['ignored_ns']>=300_000_000:
  if len(outcomes)!=1 or data.count(b' started ')!=1:raise RuntimeError('ignored edit launched command')
  entry.write_text('fn main() {} // included save\n');state['included_ns']=time.monotonic_ns()
env={**os.environ,'GOOSE':'/home/arobin/Work/Projects/goose-libs/.build/goose-time-public/.toolchain/goose/build/goose','HONK_HOME':str(out/'home'),'TMPDIR':str(root/'.build/tmp')}
result=execute([root/'.build/honk','watch','test','--offline','--filter','tests/rc.goose','--watch-dir',project/'src','--watch-recursive','--watch-ignore','generated','--watch-runs','2','--log-file',log],project,env,trace=out/'processes.jsonl.gz',trigger=trigger,timeout=60)
result['actions']=state
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
parts=result['stdout'].encode().split(b'Passed 1 test targets\n')
if len(parts)!=3 or parts[-1] or any(canonical(x+b'Passed 1 test targets\n',project)!=b'IGNORE_REAL_OK\n' for x in parts[:-1]):raise RuntimeError('canonical output mismatch')
rows=terminals(log.read_bytes())
if not result['complete'] or result['exit_code']!=0 or len(rows)!=2 or any(x['code']!=0 for x in rows) or result['stdout'].count('IGNORE_REAL_OK')!=2 or 'included_ns' not in state:raise RuntimeError('real compiler ignore smoke failed')
print('real compiler: ignored save stays idle, included save reruns; two canonical successes and clean exit0')
