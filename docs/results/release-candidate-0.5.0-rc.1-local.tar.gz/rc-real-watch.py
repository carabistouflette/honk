import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'bench'))
from watch_stress import Session,mutation
folder=root/'.build/rc-real-watch';folder.mkdir()
project=folder/'project';(project/'src').mkdir(parents=True);(project/'tests').mkdir()
(project/'Honk.toml').write_text('[package]\nname="rc_smoke"\nversion="0.1.0"\nentry="src/main.goose"\n')
entry=project/'src/main.goose';original=b'fn main() {}\n';entry.write_bytes(original)
(project/'tests/rc.goose').write_text('fn main() { print("RC_WATCH_OK"); }\n')
goose=Path('/home/arobin/Work/Projects/goose-libs/.build/goose-time-public/.toolchain/goose/build/goose')
env={**os.environ,'GOOSE':str(goose),'HONK_HOME':str(folder/'cache'),'TMPDIR':str(root/'.build/tmp')}
binary=root/'.build/honk';session=Session(binary,project,env,folder/'session','tests/rc.goose',False)
try:
 session.idle(1,0,b'RC_WATCH_OK\n')
 mutation(session,entry,original+b'// candidate edit\n','candidate-real-edit')
 session.idle(2,0,b'RC_WATCH_OK\n');session.finish()
finally:session.close()
report=dict(complete=True,code_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),honk_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),goose_sha256=hashlib.sha256(goose.read_bytes()).hexdigest(),version=subprocess.check_output([binary,'--version'],text=True).strip(),checked_successful_intervals=2,cleanup_exit=session.proc.returncode,forced_cleanup=session.record.get('forced_cleanup',False),scope='Fresh local project; real pinned compiler; recursive test watch initial run +source edit; canonical output and private-group cleanup checked. Not a long-session or public-release check.')
(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
